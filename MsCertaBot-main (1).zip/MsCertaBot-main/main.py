from br.com.certacon.BaixaLotes.flaskApp import certabot

port = 2011

if __name__ == '__main__':
    certabot.run(host="0.0.0.0", port=port)
