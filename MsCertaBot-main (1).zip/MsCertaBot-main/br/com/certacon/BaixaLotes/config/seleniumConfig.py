import json
import os
import time

import undetected_chromedriver as uc


class SeleniumConfigs:
    @staticmethod
    def get_driver_1():
        return SeleniumConfigs._create_driver(port=2222)

    @staticmethod
    def get_driver_2():
        return SeleniumConfigs._create_driver(port=2223)

    @staticmethod
    def _create_driver(port):
        tentativas = 0
        max_tentativas = 5
        espera_entre_tentativas = 5

        chrome_options = uc.ChromeOptions()
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_argument("--disable-popup-blocking")
        chrome_options.add_argument("--flag-switches-begin")
        chrome_options.add_argument("--flag-switches-end")
        chrome_options.add_argument("--origin-trial-disabled-features=WebGPU")
        chrome_options.add_argument("--disable-nacl")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        # chrome_options.add_argument("--headless")
        chrome_options.add_argument(f"--remote-debugging-port={port}")
        chrome_options.add_argument("--disable-dev-shm-usage")
        auto_select_certificate = json.dumps([{
            "pattern": "https://*",
            "filter": {"SUBJECT": {"CN": "SUPERMERCADO X LTDA:71779813000170"}}
        }])
        prefs = {
            "download.default_directory": "C:\\Users\\matheus.oliveira\\Downloads\\Arquivos Lotes",
            "--autoSelectCertificateForUrls": auto_select_certificate
        }
        chrome_options.add_experimental_option("prefs", prefs)

        executable_path = 'C:\\Users\\matheus.oliveira\\appdata\\roaming\\undetected_chromedriver\\undetected_chromedriver.exe'
        if os.path.exists(executable_path):
            try:
                return uc.Chrome(executable_path=executable_path, options=chrome_options, port=port, headless=False,
                                 version_main=120, no_sandbox=True)
            except Exception as e:
                print(f"Erro ao usar o chromedriver existente: {e}")

        while tentativas < max_tentativas:
            try:
                return uc.Chrome(options=chrome_options, headless=False, use_subprocess=True, port=port,
                                 version_main=120, no_sandbox=True)
            except PermissionError as e:
                print(f"Erro de permissão detectado: {e}. Tentando novamente em {espera_entre_tentativas} segundos...")
                time.sleep(espera_entre_tentativas)
                tentativas += 1
            except FileExistsError as e:
                print(
                    f"Erro de arquivo existente detectado: {e}. Tentando novamente em {espera_entre_tentativas} segundos...")
                time.sleep(espera_entre_tentativas)
                tentativas += 1

        raise Exception("Não foi possível criar o driver após várias tentativas")
