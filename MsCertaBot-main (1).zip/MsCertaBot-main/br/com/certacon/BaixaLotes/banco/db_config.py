from flask_sqlalchemy import SQLAlchemy

from br.com.certacon.BaixaLotes.flaskApp import certabot

db = SQLAlchemy(certabot)
