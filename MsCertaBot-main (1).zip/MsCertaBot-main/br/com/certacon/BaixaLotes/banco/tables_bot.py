import datetime

from sqlalchemy import Column, String, DateTime

from br.com.certacon.BaixaLotes.banco.db_config import db
from br.com.certacon.BaixaLotes.flaskApp import certabot


class TbCfeFaltantes(db.Model):
    __tablename__ = "TB_CFE_FALTANTES_X_26"
    ID = Column(String(255), primary_key=True)
    CHV_CFE = Column(String)
    CNPJ = Column(String)
    STATUS = Column(String)
    DATA_FALTANTES = Column(DateTime)
    NOME_REDE = Column(String)
    RAZAO_SOCIAL = Column(String)
    USUARIO = Column(String)
    NOME_MAQUINA = Column(String)

    def __init__(
        self,
        ID,
        CNPJ,
        CHV_CFE,
        STATUS,
        DATA_FALTANTES,
        NOME_REDE,
        RAZAO_SOCIAL,
        USUARIO,
        NOME_MAQUINA,
    ):
        self.ID = ID
        self.CNPJ = CNPJ
        self.CHV_CFE = CHV_CFE
        self.STATUS = STATUS
        self.DATA_FALTANTES = DATA_FALTANTES
        self.NOME_REDE = NOME_REDE
        self.RAZAO_SOCIAL = RAZAO_SOCIAL
        self.USUARIO = USUARIO
        self.NOME_MAQUINA = NOME_MAQUINA


class Certificado(db.Model):
    __tablename__ = "CERTIFICADOS_A1"
    ID_CERTIFICADO = db.Column(db.String(255), primary_key=True)
    PRIVATE_KEY = db.Column(db.String, nullable=False)
    CERTIFICATE = db.Column(db.String, nullable=False)
    FILENAME = db.Column(db.String, nullable=False)
    SENHA = db.Column(db.String, nullable=False)
    EMITENTE = db.Column(db.String)
    SUJEITO = db.Column(db.String)
    CNPJ = db.Column(db.String)
    VALIDADE_INICIAL = db.Column(db.DateTime)
    VALIDADE_FINAL = db.Column(db.DateTime)
    ARQUIVO_BASE64 = db.Column(db.Text)

    def __init__(
        self,
        ID_CERTIFICADO,
        PRIVATE_KEY,
        CERTIFICATE,
        FILENAME,
        SENHA,
        EMITENTE,
        SUJEITO,
        CNPJ,
        VALIDADE_INICIAL,
        VALIDADE_FINAL,
        ARQUIVO_BASE64,
    ):
        self.ID_CERTIFICADO = ID_CERTIFICADO
        self.PRIVATE_KEY = PRIVATE_KEY
        self.CERTIFICATE = CERTIFICATE
        self.FILENAME = FILENAME
        self.SENHA = SENHA
        self.EMITENTE = EMITENTE
        self.SUJEITO = SUJEITO
        self.CNPJ = CNPJ
        self.VALIDADE_INICIAL = VALIDADE_INICIAL
        self.VALIDADE_FINAL = VALIDADE_FINAL
        self.ARQUIVO_BASE64 = ARQUIVO_BASE64


class RobotTeste(db.Model):
    __tablename__ = "ROBOT_TESTE"
    ID_CUPOM = Column(db.String(100), primary_key=True)
    numeroChave = db.Column(String)
    cUF = Column(String)
    cNF = Column(String)
    mod = Column(String)
    xNome = Column(String)
    CNPJ = Column(String)
    dest_cnpj = Column(String)
    dest_cpf = Column(String)
    dest_xnome = Column(String)
    nserieSAT = Column(String)
    nCFe = Column(String)
    dEmi = Column(String)
    nItem = Column(String)
    cProd = Column(String)
    cEAN = Column(String)
    xProd = Column(String)
    NCM = Column(String)
    CEST = Column(String)
    CFOP = Column(String)
    qCom = Column(String)
    uCom = Column(String)
    vUnCom = Column(String)
    vProd = Column(String)
    indRegra = Column(String)
    vItem = Column(String)
    icms_orig = Column(String)
    icms_cst = Column(String)
    pis_cst = Column(String)
    pis_vBC = Column(String)
    pis_pPIS = Column(String)
    pis_vPIS = Column(String)
    cofins_cst = Column(String)
    cofins_vBC = Column(String)
    cofins_pCOFINS = Column(String)
    cofins_vCOFINS = Column(String)
    filename = Column(String)
    nome_da_maquina = Column(String)
    data_processamento = db.Column(db.DateTime)

    def __init__(
        self,
        ID_CUPOM,
        numeroChave,
        cUF,
        cNF,
        mod,
        xNome,
        CNPJ,
        dest_cnpj,
        dest_cpf,
        dest_xnome,
        nserieSAT,
        nCFe,
        dEmi,
        nItem,
        cProd,
        cEAN,
        xProd,
        NCM,
        CEST,
        CFOP,
        qCom,
        uCom,
        vUnCom,
        vProd,
        indRegra,
        vItem,
        icms_orig,
        icms_cst,
        pis_cst,
        pis_vBC,
        pis_pPIS,
        pis_vPIS,
        cofins_cst,
        cofins_vBC,
        cofins_pCOFINS,
        cofins_vCOFINS,
        filename,
        nome_da_maquina,
        data_processamento,
    ):
        self.ID_CUPOM = ID_CUPOM
        self.numeroChave = numeroChave
        self.cUF = cUF
        self.cNF = cNF
        self.mod = mod
        self.xNome = xNome
        self.CNPJ = CNPJ
        self.dest_cnpj = dest_cnpj
        self.dest_cpf = dest_cpf
        self.dest_xnome = dest_xnome
        self.nserieSAT = nserieSAT
        self.nCFe = nCFe
        self.dEmi = dEmi
        self.nItem = nItem
        self.cProd = cProd
        self.cEAN = cEAN
        self.xProd = xProd
        self.NCM = NCM
        self.CEST = CEST
        self.CFOP = CFOP
        self.qCom = qCom
        self.uCom = uCom
        self.vUnCom = vUnCom
        self.vProd = vProd
        self.indRegra = indRegra
        self.vItem = vItem
        self.icms_orig = icms_orig
        self.icms_cst = icms_cst
        self.pis_cst = pis_cst
        self.pis_vBC = pis_vBC
        self.pis_pPIS = pis_pPIS
        self.pis_vPIS = pis_vPIS
        self.cofins_cst = cofins_cst
        self.cofins_vBC = cofins_vBC
        self.cofins_pCOFINS = cofins_pCOFINS
        self.cofins_vCOFINS = cofins_vCOFINS
        self.filename = filename
        self.nome_da_maquina = nome_da_maquina
        self.data_processamento = data_processamento


class ARQUIVOS_ROBOT(db.Model):
    __tablename__ = "ARQUIVOS_ROBOT"
    ID = db.Column(db.Integer, primary_key=True)
    NOME_ARQUIVO = db.Column(db.String, nullable=False)
    STATUS = db.Column(db.String, nullable=False)
    DATA_INSERCAO = db.Column(db.DateTime, default=datetime.datetime)

    def __int__(self, ID, NOME_ARQUIVO, STATUS, DATA_INSERCAO):
        self.ID = ID
        self.NOME_ARQUIVO = NOME_ARQUIVO
        self.STATUS = STATUS
        self.DATA_INSERCAO = DATA_INSERCAO


with certabot.app_context():
    db.create_all()
