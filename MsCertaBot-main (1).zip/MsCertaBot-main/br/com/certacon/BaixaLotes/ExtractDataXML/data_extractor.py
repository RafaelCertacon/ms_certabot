import os
import uuid

from .name_space import NAMESPACE


def processar_elementos_cfe(root, data, data_processamento, xml_file):
    lote_cfe_element = root.find('.//ns:LoteCFe', namespaces=NAMESPACE)
    if lote_cfe_element is not None:
        cfe_elements = lote_cfe_element.findall('.//ns:CFe', namespaces=NAMESPACE)
        for cfe_element in cfe_elements:
            for extracted_data in extrair_dados_cfe(cfe_element, data_processamento, xml_file):
                data.append(extracted_data)


def extrair_dados_cfe(cfe_element, data_processamento, xml_file):
    infCFe = cfe_element.find('.//ns:infCFe', namespaces=NAMESPACE)
    if infCFe is not None:
        numeroChave = infCFe.get('Id')

        emit_element = cfe_element.find('.//ns:emit', namespaces=NAMESPACE)
        xNome, cnpj = None, None
        if emit_element is not None:
            xNome = emit_element.findtext('.//ns:xNome', namespaces=NAMESPACE)
            cnpj = emit_element.findtext('.//ns:CNPJ', namespaces=NAMESPACE)

        dest_element = cfe_element.find('.//ns:dest', namespaces=NAMESPACE)
        dest_xnome, dest_cnpj, dest_cpf = None, None, None
        if dest_element is not None:
            dest_xnome = dest_element.findtext('.//ns:xNome', namespaces=NAMESPACE)
            dest_cnpj = dest_element.findtext('.//ns:CNPJ', namespaces=NAMESPACE)
            dest_cpf = dest_element.findtext('.//ns:CPF', namespaces=NAMESPACE)

        ide_element = cfe_element.find('.//ns:ide', namespaces=NAMESPACE)
        cUF, cNF, mod, nserieSAT, nCFe, dEmi = None, None, None, None, None, None
        if ide_element is not None:
            cUF = ide_element.findtext('.//ns:cUF', namespaces=NAMESPACE)
            cNF = ide_element.findtext('.//ns:cNF', namespaces=NAMESPACE)
            mod = ide_element.findtext('.//ns:mod', namespaces=NAMESPACE)
            nserieSAT = ide_element.findtext('.//ns:nserieSAT', namespaces=NAMESPACE)
            nCFe = ide_element.findtext('.//ns:nCFe', namespaces=NAMESPACE)
            dEmi = ide_element.findtext('.//ns:dEmi', namespaces=NAMESPACE)

        det_elements = cfe_element.findall('.//ns:det', namespaces=NAMESPACE)
        for det_element in det_elements:
            produto = extrair_dados_produto(det_element)
            if produto:
                id_cupom = str(uuid.uuid4())
                extracted_data = {
                    'ID_CUPOM': id_cupom,
                    'numeroChave': numeroChave.replace('CFe', ''),
                    'cUF': cUF,
                    'cNF': cNF,
                    'mod': mod,
                    'xNome': xNome,
                    'CNPJ': cnpj,
                    'dest_cnpj': dest_cnpj,
                    'dest_cpf': dest_cpf,
                    'dest_xnome': dest_xnome,
                    'nserieSAT': nserieSAT,
                    'nCFe': nCFe,
                    'dEmi': dEmi,
                    **produto,
                    'filename': os.path.basename(xml_file),
                    'nome_da_maquina': None,
                    'data_processamento': data_processamento,
                }
                yield extracted_data


def extrair_dados_produto(det_element):
    nItem = int(det_element.get('nItem'))
    cProd = det_element.findtext('.//ns:cProd', namespaces=NAMESPACE)
    xProd = det_element.findtext('.//ns:xProd', namespaces=NAMESPACE)
    NCM = det_element.findtext('.//ns:NCM', namespaces=NAMESPACE)
    CFOP = det_element.findtext('.//ns:CFOP', namespaces=NAMESPACE)
    qCom = det_element.findtext('.//ns:qCom', namespaces=NAMESPACE)
    uCom = det_element.findtext('.//ns:uCom', namespaces=NAMESPACE)
    vUnCom = det_element.findtext('.//ns:vUnCom', namespaces=NAMESPACE)
    vProd = det_element.findtext('.//ns:vProd', namespaces=NAMESPACE)
    vItem = det_element.findtext('.//ns:vItem', namespaces=NAMESPACE)
    cean = det_element.findtext('.//ns:cEAN', namespaces=NAMESPACE)
    CEST = det_element.findtext('.//ns:CEST', namespaces=NAMESPACE)
    indRegra = det_element.findtext('.//ns:indRegra', namespaces=NAMESPACE)

    icms_element = det_element.find('.//ns:imposto/ns:ICMS/*', namespaces=NAMESPACE)
    icms_orig, icms_cst = None, None
    if icms_element is not None:
        icms_orig = icms_element.findtext('.//ns:Orig', namespaces=NAMESPACE)
        icms_cst = icms_element.findtext('.//ns:CST', namespaces=NAMESPACE)

    pis_element = det_element.find('.//ns:PIS', namespaces=NAMESPACE)
    pis_cst, pis_vBC, pis_pPIS, pis_vPIS = None, None, None, None
    if pis_element is not None:
        pis_cst = pis_element.findtext('.//ns:CST', namespaces=NAMESPACE)
        pis_vBC = pis_element.findtext('.//ns:vBC', namespaces=NAMESPACE)
        pis_pPIS = pis_element.findtext('.//ns:pPIS', namespaces=NAMESPACE)
        pis_vPIS = pis_element.findtext('.//ns:vPIS', namespaces=NAMESPACE)

    cofins_element = det_element.find('.//ns:COFINS', namespaces=NAMESPACE)
    cofins_cst, cofins_vBC, cofins_pCOFINS, cofins_vCOFINS = None, None, None, None
    if cofins_element is not None:
        cofins_cst = cofins_element.findtext('.//ns:CST', namespaces=NAMESPACE)
        cofins_vBC = cofins_element.findtext('.//ns:vBC', namespaces=NAMESPACE)
        cofins_pCOFINS = cofins_element.findtext('.//ns:pCOFINS', namespaces=NAMESPACE)
        cofins_vCOFINS = cofins_element.findtext('.//ns:vCOFINS', namespaces=NAMESPACE)

    produto = {
        'nItem': nItem,
        'cProd': cProd,
        'cEAN': cean,
        'xProd': xProd,
        'NCM': NCM,
        'CEST': CEST,
        'CFOP': CFOP,
        'qCom': qCom,
        'uCom': uCom,
        'vUnCom': vUnCom,
        'vProd': vProd,
        'indRegra': indRegra,
        'vItem': vItem,
        'icms_orig': icms_orig,
        'icms_cst': icms_cst,
        'pis_cst': pis_cst,
        'pis_vBC': pis_vBC,
        'pis_pPIS': pis_pPIS,
        'pis_vPIS': pis_vPIS,
        'cofins_cst': cofins_cst,
        'cofins_vBC': cofins_vBC,
        'cofins_pCOFINS': cofins_pCOFINS,
        'cofins_vCOFINS': cofins_vCOFINS
    }
    return produto
