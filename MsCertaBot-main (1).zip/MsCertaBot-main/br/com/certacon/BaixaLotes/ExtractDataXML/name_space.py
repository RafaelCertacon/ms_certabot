NAMESPACE = {'ns': 'http://www.fazenda.sp.gov.br/sat'}
