import datetime
import os
import xml.etree.ElementTree as ET

from br.com.certacon.BaixaLotes.ImportBCP.import_base import execute_bcp
from .data_extractor import processar_elementos_cfe
from .file_operations import salvar_dados_em_csv, mover_para_pasta_de_erro
from .xml_parser import ler_e_parsear_xml


def processar_arquivo_xml(xml_files, horario_atual):
    destino_csv = 'C:\\Users\\matheus.oliveira\\Downloads\\11068476000180 - CFe-SAT\\CFe-SAT\\Emitidas\\EM EXECEL'

    for xml_file in xml_files:
        try:
            data = []
            horario_formatado = horario_atual.strftime("%Y-%m-%d %H:%M:%S")
            data_processamento = horario_formatado

            root = ler_e_parsear_xml(xml_file)
            processar_elementos_cfe(root, data, data_processamento, xml_file)

            if data:
                salvar_dados_em_csv(data, xml_file, destino_csv)
                nome_arquivo_csv = os.path.join(destino_csv, os.path.basename(xml_file) + '.csv')
                print(nome_arquivo_csv)
                execute_bcp(nome_arquivo_csv)
        except ET.ParseError:
            mover_para_pasta_de_erro(xml_file)


if __name__ == "__main__":
    folder = 'C:\\Users\\matheus.oliveira\\Downloads\\11068476000180 - CFe-SAT\\CFe-SAT\\Emitidas\\EM EXECEL'
    xml_files = [os.path.join(folder, file) for file in os.listdir(folder) if file.endswith('.xml')]
    horario_atual = datetime.datetime.now()
    processar_arquivo_xml(xml_files, horario_atual)
