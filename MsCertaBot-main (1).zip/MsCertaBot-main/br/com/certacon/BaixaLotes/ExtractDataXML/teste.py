import glob

import pandas as pd

xml_folder = 'C:\\Users\\matheus.oliveira\\Downloads\\11068476000180 - CFe-SAT\\CFe-SAT\\Emitidas\\EM EXECEL\\'
xml_files = glob.glob(xml_folder + '*.xml')

df_final_products = pd.DataFrame()

for xml_file in xml_files:

    df_infCFe = pd.read_xml(xml_file, xpath="//infCFe")
    df_ide = pd.read_xml(xml_file, xpath="//ide").rename(columns={'CNPJ': 'CNPJ_ide'})
    df_emit = pd.read_xml(xml_file, xpath="//emit").rename(columns={'CNPJ': 'CNPJ_emit'})
    df_enderemit = pd.read_xml(xml_file, xpath="//enderEmit")

    df_superior = pd.concat([df_infCFe, df_ide, df_emit, df_enderemit], axis=1)

    df_dets = pd.read_xml(xml_file, xpath="//det")
    df_prods = pd.read_xml(xml_file, xpath="//det/prod")

    if df_dets is not None and not df_dets.empty:

        df_dets['nItem'] = df_dets.index + 1

        for i, det in df_dets.iterrows():
            df_superior_replicated = pd.concat([df_superior] * len(df_dets), ignore_index=True)
            df_det = pd.DataFrame([det])
            df_prod = pd.DataFrame([df_prods.iloc[i]])

            df_combined = pd.concat(
                [df_superior_replicated, df_det.reset_index(drop=True), df_prod.reset_index(drop=True)], axis=1)
            df_final_products = pd.concat([df_final_products, df_combined], ignore_index=True)

columns_to_drop = ['signAC', 'assinaturaQRCODE', 'ide', 'emit', 'dest', 'total', 'pgto', 'infAdic', 'obsFisco',
                   'ICMSSN102', 'PISSN', 'COFINSSN', 'imposto', 'enderEmit', 'prod']
df_final_products.drop(columns=columns_to_drop, errors='ignore', inplace=True)

df_final_products = df_final_products.dropna(subset=['nItem'])

excel_path = xml_folder + 'dados_combinados.xlsx'
df_final_products.to_excel(excel_path, index=False)

print(f'Dados combinados exportados para {excel_path}')
