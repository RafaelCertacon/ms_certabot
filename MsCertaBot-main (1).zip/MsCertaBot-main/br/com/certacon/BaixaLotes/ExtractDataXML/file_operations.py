import os
import shutil

import pandas as pd


def salvar_dados_em_csv(data, xml_file, destino_csv):
    """
    Salva os dados extraídos em um arquivo CSV.

    Args:
    data (list): Lista de dicionários com os dados extraídos.
    xml_file (str): Caminho do arquivo XML de origem.
    destino_csv (str): Diretório onde os arquivos CSV serão salvos.
    """
    if data:
        df = pd.DataFrame(data)
        nome_arquivo_csv = os.path.join(destino_csv, os.path.basename(xml_file) + '.csv')
        df.to_csv(nome_arquivo_csv, index=False, sep=';')
        print(f"Arquivo salvo: {nome_arquivo_csv}")


def mover_para_pasta_de_erro(xml_file):
    """
    Move o arquivo XML para a pasta de erro.

    Args:
    xml_file (str): Caminho do arquivo XML que causou o erro.
    """
    error_folder = '/home/robot1/Documentos/erro'
    if not os.path.exists(error_folder):
        os.makedirs(error_folder)
    shutil.move(xml_file, os.path.join(error_folder, os.path.basename(xml_file)))
    print(f"Arquivo movido para a pasta de erro: {os.path.join(error_folder, os.path.basename(xml_file))}")
