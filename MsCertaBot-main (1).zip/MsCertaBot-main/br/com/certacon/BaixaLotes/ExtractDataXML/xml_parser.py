import xml.etree.ElementTree as ET


def ler_e_parsear_xml(xml_file):
    tree = ET.parse(xml_file)
    return tree.getroot()
