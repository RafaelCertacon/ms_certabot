import ctypes
import subprocess
import sys


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def adicionar_politica(nomecertificado):
    comando_registro = r'reg add "HKCU\Software\Policies\Google\Chrome\AutoSelectCertificateForUrls" /v "1" /t REG_SZ /d "{{\"pattern\":\"https://*\",\"filter\":{{\"SUBJECT\":{{\"CN\":\"{}\"}}}}}}" /f'.format(
        nomecertificado
    )
    if is_admin():
        try:
            subprocess.run(comando_registro, check=True, shell=True)
            print("Política adicionada com sucesso.")
        except subprocess.CalledProcessError as e:
            print(f"Erro ao adicionar a política: {e}")
    else:
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, " ".join(sys.argv), None, 1
        )


nome_certificado = "SUPERMERCADO X LTDA:71779813000170"
adicionar_politica(nome_certificado)
