import json
import os
import subprocess


def create_nss(pem_path: str, senha_pfx: str, caminho_key: str, caminho_pfx: str):
    try:
        with open(caminho_key, "w") as file:
            file.write(senha_pfx)

        home_dir = os.environ.get("HOME")
        home_nss_dir = f"{home_dir}/.pki/nssdb"
        home_nss = f"sql:{home_nss_dir}"

        if not os.path.exists(home_nss_dir):
            os.makedirs(home_nss_dir, exist_ok=True)
            subprocess.run(["certutil", "-N", "-d", home_nss, "--empty-password"])
        else:
            print("O diretório do banco de dados NSS já existe e será reutilizado.")

        return caminho_key, home_nss
    except subprocess.CalledProcessError as e:
        raise e


def install_pfx(caminho_pfx: str, home_nss: str, caminho_key: str):
    subprocess.run(
        ["pk12util", "-i", caminho_pfx, "-d", home_nss, "-w", caminho_key],
        text=True,
        check=True,
    )
    # subprocess.run(input="\n\n", text=True, check=True)
    os.remove(caminho_key)


def converter_pfx_para_pem(caminho_pfx, senha_pfx, caminho_saida_pem):
    try:
        subprocess.run(
            [
                "openssl",
                "pkcs12",
                "-in",
                caminho_pfx,
                "-out",
                caminho_saida_pem,
                "-nodes",
                "-passin",
                f"pass:{senha_pfx}",
                "-legacy",
            ],
            check=True,
        )
        print("Conversão PFX para PEM realizada com sucesso.")
        return caminho_saida_pem
    except subprocess.CalledProcessError as e:
        print(
            "Erro ao converter PFX para PEM. Verifique o caminho e a senha do arquivo PFX."
        )
        raise e


def extrair_cn(caminho_pem):
    try:
        cmd = ["openssl", "x509", "-in", caminho_pem, "-noout", "-subject"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        cn_line = [line for line in result.stdout.split("\n") if "CN = " in line][0]
        cn = cn_line.split("CN = ")[-1].split("/")[0]
        return cn
    except subprocess.CalledProcessError as e:
        print("Erro ao extrair CN do certificado.")
        raise e


def criar_politica_chrome(cn: str):
    politica = {
        "AutoSelectCertificateForUrls": [
            json.dumps(
                {
                    "pattern": "https://*",
                    "filter": {"SUBJECT": {"CN": cn.replace('"', "")}},
                }
            )
        ]
    }
    diretorio_politicas = "/etc/opt/chrome/policies/managed/"
    arquivo_politica = os.path.join(diretorio_politicas, "policies.json")

    os.makedirs(diretorio_politicas, exist_ok=True)

    with open(arquivo_politica, "w") as arquivo:
        json.dump(politica, arquivo, indent=4)

    print(f"Política criada com sucesso em: {arquivo_politica}")


caminho_pfx = (
    "/home/servicedesk/Documentos/pfx_project/test-certs/Wayne Enterprises, Inc.pfx"
)
senha_pfx = "1234"
caminho_saida_pem = (
    "/home/servicedesk/Documentos/pfx_project/test-certs/Wayne Enterprises, Inc.pem"
)
caminho_key = (
    "/home/servicedesk/Documentos/pfx_project/test-certs/Wayne Enterprises, Inc.data"
)

try:
    pen_path = converter_pfx_para_pem(caminho_pfx, senha_pfx, caminho_saida_pem)
    create_nss(pen_path, senha_pfx, caminho_key, caminho_pfx)

    cn = extrair_cn(caminho_saida_pem)
    print(f"CN extraído: {cn}")

    criar_politica_chrome(cn)
except Exception as e:
    print(f"Ocorreu um erro: {e}")
