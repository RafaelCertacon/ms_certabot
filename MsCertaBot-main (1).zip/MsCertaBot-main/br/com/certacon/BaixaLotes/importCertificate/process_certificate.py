from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import pkcs12


def processar_certificado(cert_file_path, password):
    with open(cert_file_path, "rb") as f:
        pfx_data = f.read()
    password_bytes = password.encode('utf-8')

    private_key, certificate, _ = pkcs12.load_key_and_certificates(pfx_data, password_bytes, default_backend())

    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
    )

    certificate_pem = certificate.public_bytes(serialization.Encoding.PEM)

    cert = x509.load_pem_x509_certificate(certificate_pem, default_backend())

    emitente = cert.issuer

    sujeito = cert.subject
    validade_inicial = cert.not_valid_before
    validade_final = cert.not_valid_after

    emitente_str = emitente.rfc4514_string()
    sujeito_str = sujeito.rfc4514_string()

    return private_key_pem, certificate_pem, emitente_str, sujeito_str, validade_inicial, validade_final
