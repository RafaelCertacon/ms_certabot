def find_cnpj(sujeito_str):
    parts = sujeito_str.split(",")
    cnpj = None

    for part in parts:
        if part.startswith("L:"):
            cnpj = part[2:]
        if part.startswith("CN="):
            cnpj = part.split(":")[1]

    return cnpj
