import subprocess


def execute_bcp(data_file, table="ROBOT_TESTE", server="192.168.0.26", username="matheus.oliveira",
                password="Makron3254",
                database="CertaBot", schema=None):
    bcp_command = ["bcp", f"{table}", "in", data_file, "-S", server, "-U", username, "-P", password]
    if database:
        bcp_command.extend(["-d", database])
    if schema:
        bcp_command.extend(["-S", server, "-d", database, "-t", ";", "-c", "-F", "2"])
    else:
        bcp_command.extend(["-c", "-t", ";", "-F", "2"])
    try:
        subprocess.run(bcp_command, check=True)
        print("BCP executado com sucesso.")
    except subprocess.CalledProcessError as e:
        print(f"Erro ao executar o BCP: {e}")
