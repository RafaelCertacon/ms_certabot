import os
import time

from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, \
    StaleElementReferenceException
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class SeleniumActions:

    def __init__(self, driver):
        self.driver = driver

    def open_website(self, url):
        self.driver.get(url)

    def verificar_e_prosseguir(self, url_esperada):
        if self.driver.current_url != url_esperada:
            self.driver.get(url_esperada)

    def _tratar_erro_de_navegador(self, e, tentativas, max_tentativas):
        if "session deleted because of page crash" in str(e) or "cannot determine loading status" in str(e):
            if tentativas < max_tentativas - 1:
                print(f"Falha na página detectada. Tentativa {tentativas + 1} de {max_tentativas}")
                self.driver.refresh()
                time.sleep(5)
            else:
                print("Número máximo de tentativas atingido. A operação pode não ter sido concluída.")
        else:
            raise

    def entrada(self, cnpjs):
        try:
            contribuinte_option = self.driver.find_element(By.ID, "conteudo_rbtContribuinte")
            contribuinte_option.click()

            selecionar_certificado = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "conteudo_imgCertificado")))
            selecionar_certificado.click()

            selecionar_cnpj = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "conteudo_txtCNPJ_ContribuinteFilial")))
            selecionar_cnpj.click()

            indice_barra = cnpjs.index("/") + 1
            numeros_apos_barra = cnpjs[indice_barra:]
            selecionar_cnpj.send_keys(numeros_apos_barra)

            pesquisar = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "conteudo_btnPesquisar")))
            pesquisar.click()

            primeiroCNPJ = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.ID, "conteudo_gridCNPJ_lnkCNPJ_0")))
            primeiroCNPJ.click()

            self.driver.execute_script(
                'window.open("https://satsp.fazenda.sp.gov.br/COMSAT/Private/ConsultaCfeSemErros/ConsultarCfeSemErro.aspx", "_blank");')
            self.driver.switch_to.window(self.driver.window_handles[-1])
        except TimeoutException:
            print("Um dos elementos não foi carregado a tempo")

    def baixar(self, chv_cfe):
        self.verificar_e_prosseguir(
            "https://satsp.fazenda.sp.gov.br/COMSAT/Private/ConsultaCfeSemErros/ConsultarCfeSemErro.aspx")
        try:
            self._tentar_clicar_e_enviar_chaves("conteudo_txtChaveAcesso", chv_cfe)
            self._tentar_clicar("conteudo_btnPesquisar")
        except TimeoutException:
            print("O campo de chave de acesso ou botão pesquisar não foi carregado a tempo")

    def _tentar_clicar(self, element_id):
        tentativas = 0
        max_tentativas = 3
        while tentativas < max_tentativas:
            try:
                elemento = WebDriverWait(self.driver, 10).until(
                    EC.visibility_of_element_located((By.ID, element_id)))
                elemento.click()
                return
            except (ElementClickInterceptedException, StaleElementReferenceException):
                pass
            except WebDriverException as e:
                self._tratar_erro_de_navegador(e, tentativas, max_tentativas)
            tentativas += 1

    def _tentar_clicar_e_enviar_chaves(self, element_id, keys):
        tentativas = 0
        while tentativas < 3:
            try:
                elemento = WebDriverWait(self.driver, 10).until(
                    EC.visibility_of_element_located((By.ID, element_id)))
                elemento.click()
                elemento.send_keys(Keys.CONTROL + "a")
                elemento.send_keys(Keys.BACK_SPACE)
                elemento.send_keys(keys)
                return
            except ElementClickInterceptedException:
                self._fechar_modal()
            except StaleElementReferenceException:
                pass
            tentativas += 1
        raise Exception("Não foi possível interagir com o elemento após várias tentativas")

    def _fechar_modal(self):
        try:
            modal_btn = WebDriverWait(self.driver, 5).until(
                EC.visibility_of_element_located((By.XPATH, "/html/body/div[2]/div[3]/div/button")))
            modal_btn.click()
            print("Modal encontrado e fechado")
        except TimeoutException:
            print("Modal não encontrado")

    def verificar_se_arquivo_existe(self):
        try:
            link = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "conteudo_grvConsultaCfeSemErros_lkbDownloadXml_0")))
            nome_do_arquivo = link.text + ".xml"
            caminho_do_arquivo = os.path.join("C:/Users/matheus.oliveira/Downloads/Arquivos Lotes/", nome_do_arquivo)
            print("Caminho do arquivo:", caminho_do_arquivo)
            existe = os.path.exists(caminho_do_arquivo)
            print("Retorno", existe)
            return not existe, caminho_do_arquivo
        except TimeoutException:
            print("Não foi possível localizar o link de download.")
            return False, None

    def realizar_download(self, cnpj):
        tentativas = 0
        max_tentativas = 3

        while tentativas < max_tentativas:
            try:
                arquivo_nao_existe, caminho_do_arquivo = self.verificar_se_arquivo_existe()
                if arquivo_nao_existe:

                    link = WebDriverWait(self.driver, 10).until(
                        EC.element_to_be_clickable((By.ID, "conteudo_grvConsultaCfeSemErros_lkbDownloadXml_0")))
                    link.click()
                    print("Download iniciado.")
                    break
                else:
                    print("Arquivo já existe. Download não realizado.")
                    break
            except TimeoutException:
                print("O link para download não foi carregado a tempo")
                self.entrada(cnpj)
            except WebDriverException as e:
                if "session deleted because of page crash" in str(e):
                    print(f"Falha na página. Tentativa {tentativas + 1} de {max_tentativas}")
                    self.driver.refresh()
                    time.sleep(5)
                    self.entrada(cnpj)
                else:
                    raise
            tentativas += 1

        if tentativas == max_tentativas:
            print("Número máximo de tentativas atingido")

