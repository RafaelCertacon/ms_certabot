import os
import xml.etree.ElementTree as ET


def obter_ultimo_arquivo_xml(diretorio):
    arquivos_xml = [arq for arq in os.listdir(diretorio) if arq.endswith('.xml')]
    caminho_completo = [os.path.join(diretorio, arq) for arq in arquivos_xml]
    print(caminho_completo)
    return max(caminho_completo, key=os.path.getmtime, default=None)


def retirachaves(diretorio):
    xml_file = obter_ultimo_arquivo_xml(diretorio)
    print(diretorio)
    if not xml_file:
        print("Nenhum arquivo XML encontrado.")
        return

    chaves = []

    try:
        tree = ET.parse(xml_file)
        root = tree.getroot()
        namespace = {'ns': 'http://www.fazenda.sp.gov.br/sat'}
        lote_cfe_element = root.find('.//ns:LoteCFe', namespaces=namespace)
        if lote_cfe_element is not None:
            cfe_elements = lote_cfe_element.findall('.//ns:CFe', namespaces=namespace)
            for cfe_element in cfe_elements:
                infCFe = cfe_element.find('.//ns:infCFe', namespaces=namespace)
                if infCFe is not None:
                    numeroChave = infCFe.get('Id').replace("CFe", "")
                    chaves.append(numeroChave)
    except Exception as e:
        print(f"Erro ao processar o arquivo {xml_file}: {e}")
    return chaves
