import os
import xml.etree.ElementTree as ET


def obter_arquivos_xml(diretorio):
    """
    Retorna todos os arquivos XML em um diretório.
    """
    arquivos_xml = [arq for arq in os.listdir(diretorio) if arq.endswith('.xml')]
    caminho_completo = [os.path.join(diretorio, arq) for arq in arquivos_xml]
    return caminho_completo


def contar_chaves_em_xml(xml_file):
    """
    Conta as chaves em um arquivo XML.
    """

    chaves = []

    try:
        tree = ET.parse(xml_file)
        root = tree.getroot()
        namespace = {'ns': 'http://www.fazenda.sp.gov.br/sat'}
        lote_cfe_element = root.find('.//ns:LoteCFe', namespaces=namespace)
        if lote_cfe_element is not None:
            cfe_elements = lote_cfe_element.findall('.//ns:CFe', namespaces=namespace)
            for cfe_element in cfe_elements:
                infCFe = cfe_element.find('.//ns:infCFe', namespaces=namespace)
                if infCFe is not None:
                    numeroChave = infCFe.get('Id').replace("CFe", "")
                    chaves.append(numeroChave)
    except Exception as e:
        print(f"Erro ao processar o arquivo {xml_file}: {e}")
    return chaves


def contar_chaves_em_todos_xml(diretorio):
    """
    Conta o número de chaves em todos os arquivos XML em um diretório.
    """
    arquivos_xml = obter_arquivos_xml(diretorio)
    total_chaves = 0
    for xml_file in arquivos_xml:
        chaves = contar_chaves_em_xml(xml_file)
        total_chaves += len(chaves)
    return total_chaves


diretorio = 'C:\\Users\\matheus.oliveira\\Downloads\\Arquivos Lotes'
print("Número total de chaves:", contar_chaves_em_todos_xml(diretorio))
