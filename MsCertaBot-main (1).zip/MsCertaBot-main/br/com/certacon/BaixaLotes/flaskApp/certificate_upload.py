import os
import re
import uuid

from flask import request, jsonify
from sqlalchemy.exc import IntegrityError
from werkzeug.utils import secure_filename

from . import certabot
from ..banco.tables_bot import Certificado, db
from ..importCertificate.certificate_cnpj import find_cnpj
from ..importCertificate.process_certificate import processar_certificado
from ..importCertificate.set_up_google_certified import (
    converter_pfx_para_pem,
    create_nss,
    criar_politica_chrome,
    install_pfx,
)


@certabot.route("/upload_certificado", methods=["POST"])
def upload_certificado():
    if "arquivo" not in request.files:
        return (
            jsonify({"message": "Nenhum arquivo parte do request", "status": "error"}),
            400,
        )
    arquivo = request.files["arquivo"]

    if arquivo.filename == "":
        return (
            jsonify({"message": "Nenhum arquivo selecionado", "status": "error"}),
            400,
        )

    senha = request.form.get("senha")
    nome = secure_filename(arquivo.filename)

    if not senha:
        return jsonify({"message": "A senha é obrigatória", "status": "error"}), 400
    if not nome:
        return (
            jsonify(
                {"message": "O nome do certificado é obrigatório", "status": "error"}
            ),
            400,
        )

    caminho_destino = os.path.join(os.getcwd(), nome)
    arquivo.save(caminho_destino)

    try:
        (
            private_key_pem,
            certificate_pem,
            emitente_str,
            sujeito_str,
            validade_inicial,
            validade_final,
        ) = processar_certificado(caminho_destino, senha)

        if private_key_pem is None:
            return (
                jsonify(
                    {"message": "Senha incorreta. Certificado não pode ser processado."}
                ),
                400,
            )

        cnpj = find_cnpj(sujeito_str)
        match = re.search(r"CN=([^,]+)", sujeito_str)

        if match:
            cn_certificate = match.group(1)
        else:
            return (
                jsonify({"message": "Padrão CN= não encontrado no certificado."}),
                400,
            )

        certificado_existente = Certificado.query.filter_by(
            FILENAME=nome, CNPJ=cnpj
        ).first()
        if certificado_existente:
            return jsonify({"message": "Certificado já existe no banco de dados."}), 400

        novo_certificado = Certificado(
            ID_CERTIFICADO=str(uuid.uuid4()),
            PRIVATE_KEY=private_key_pem.decode("utf-8"),
            CERTIFICATE=certificate_pem.decode("utf-8"),
            FILENAME=nome,
            SENHA=senha,
            EMITENTE=emitente_str,
            SUJEITO=sujeito_str,
            CNPJ=cnpj,
            VALIDADE_INICIAL=validade_inicial,
            VALIDADE_FINAL=validade_final,
            ARQUIVO_BASE64=None,
        )

        db.session.add(novo_certificado)
        db.session.commit()

        converter_pfx_para_pem(caminho_destino, senha, caminho_destino + ".pem")
        caminho_key, home_nss = create_nss(
            caminho_destino + ".pem",
            senha,
            caminho_destino.replace(".pfx", ".data"),
            caminho_destino,
        )
        install_pfx(caminho_destino, home_nss, caminho_key)
        criar_politica_chrome(cn_certificate)

        return (
            jsonify(
                {
                    "message": "Certificado salvo e máquina configurada com sucesso",
                    "certificado_id": novo_certificado.ID_CERTIFICADO,
                    "CNPJ": cnpj,
                    "VALIDADE_INICIAL": validade_inicial.strftime("%d/%m/%Y"),
                    "VALIDADE_FINAL": validade_final.strftime("%d/%m/%Y"),
                }
            ),
            200,
        )

    except IntegrityError:
        db.session.rollback()
        return jsonify({"message": "Certificado já existe no banco de dados."}), 400
    except Exception as e:
        if "Invalid password or PKCS12 data" in str(e):
            return (
                jsonify(
                    {
                        "message": "Senha do certificado é inválida ou formato PKCS12 inválido."
                    }
                ),
                400,
            )
        else:
            return (
                jsonify({"message": f"Erro ao processar o certificado: {str(e)}"}),
                500,
            )
