from flask import jsonify
from sqlalchemy.sql import text

from . import certabot
from ..banco.tables_bot import db


@certabot.route('/docCupom/<chave>', methods=['GET'])
def get_dados_robot(chave):
    try:
        sql = text("SELECT * FROM ROBOT_TESTE WHERE numeroChave = :chave")
        resultado = db.session.execute(sql, {'chave': chave})
        print(resultado)
        registros = resultado.fetchall()
        print(registros)
        dados = [
            {
                'nItem': registro.nItem,
                'xProd': registro.xProd,
                'cProd': registro.cProd,
                'CNPJ': registro.CNPJ,
                'dest_cnpj': registro.dest_cnpj,
                'dest_cpf': registro.dest_cpf,
                'dest_xnome': registro.dest_xnome,
                'nserieSAT': registro.nserieSAT,
                'nCFe': registro.nCFe,
                'dEmi': registro.dEmi,
                'cEAN': registro.cEAN,
                'NCM': registro.NCM,
                'CEST': registro.CEST,
                'CFOP': registro.CFOP,
                'qCom': registro.qCom,
                'uCom': registro.uCom,
                'vUnCom': registro.vUnCom,
                'vProd': registro.vProd,
                'indRegra': registro.indRegra,
                'vItem': registro.vItem,
                'icms_orig': registro.icms_orig,
                'icms_cst': registro.icms_cst,
                'pis_cst': registro.pis_cst,
                'pis_vBC': registro.pis_vBC,
                'pis_pPIS': registro.pis_pPIS,
                'pis_vPIS': registro.pis_vPIS,
                'cofins_cst': registro.cofins_cst,
                'cofins_vBC': registro.cofins_vBC,
                'cofins_pCOFINS': registro.cofins_pCOFINS,
                'cofins_vCOFINS': registro.cofins_vCOFINS
            }
            for registro in registros
        ]
        return jsonify(dados), 200
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar dados: {str(e)}'}), 500
