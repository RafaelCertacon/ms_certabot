import datetime
from threading import Thread

import numpy as np
import pandas as pd
from flask import request, jsonify

from br.com.certacon.BaixaLotes.config.seleniumConfig import SeleniumConfigs
from . import certabot
from ..ExtractDataXML.create_csv import processar_arquivo_xml
from ..actions import SeleniumActions
from ..banco.tables_bot import TbCfeFaltantes

selenium_config = SeleniumConfigs()

horario_atual = datetime.datetime.now()


@certabot.route("/baixar", methods=["POST"])
def process_file():
    data = request.json
    cnpj = data.get("cnpj")
    if not cnpj:
        return jsonify({"error": "CNPJ não fornecido"}), 400

    try:
        registros = TbCfeFaltantes.query.filter_by(CNPJ=cnpj, STATUS="CRIADO").all()
        df = pd.DataFrame([vars(registro) for registro in registros])
        partes = np.array_split(df, 2)

        def process_part(parts, get_driver_func):
            driver = get_driver_func()
            actions = SeleniumActions(driver)
            actions.open_website(
                "https://satsp.fazenda.sp.gov.br/COMSAT/Private/Default.aspx"
            )
            actions.entrada(cnpjs=cnpj)
            for _, registro in parts.iterrows():
                chv_cfe = registro["CHV_CFE"]
                actions.baixar(chv_cfe=chv_cfe)
                actions.realizar_download(cnpj)
                caminho = actions.verificar_se_arquivo_existe()
                caminho_do_arquivo = caminho[1]

            driver.quit()
            processar_arquivo_xml([caminho_do_arquivo], horario_atual)

        threads = []

        for i, part in enumerate(partes):
            thread = Thread(
                target=process_part,
                args=(part, getattr(selenium_config, f"get_driver_{i + 1}")),
            )
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()
        return jsonify({"success": "Files downloaded successfully"})

    except Exception as e:
        return jsonify({"error": str(e)})
