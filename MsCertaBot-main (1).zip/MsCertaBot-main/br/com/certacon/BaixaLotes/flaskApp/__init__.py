from flask import Flask
from flask_swagger_ui import get_swaggerui_blueprint

certabot = Flask(__name__)

certabot.config["SQLALCHEMY_DATABASE_URI"] = (
    "mssql+pyodbc://matheus.oliveira:Makron3254@192.168.0.26/CertaBot?driver=ODBC+Driver+17+for+SQL+Server"
)

swaggerui_blueprint = get_swaggerui_blueprint(
    "/swagger",
    "static/swagger.json",
    config={"app_name": "Minha API Flask"},
)

certabot.register_blueprint(swaggerui_blueprint, url_prefix="/swagger")

from ..flaskApp import baixa_cfe
from ..flaskApp import upload_faltantes
from ..flaskApp import certificate_upload
from ..flaskApp import doc_by_key
