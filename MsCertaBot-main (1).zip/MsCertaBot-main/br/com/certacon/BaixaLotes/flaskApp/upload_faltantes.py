import getpass
import socket
import uuid
from datetime import datetime

import pandas as pd
from flask import request, jsonify

from . import certabot
from ..banco.tables_bot import TbCfeFaltantes, Certificado, db, ARQUIVOS_ROBOT

user_name = getpass.getuser()
host_name = socket.gethostname()


@certabot.route("/faltantes", methods=["POST"])
def upload_arquivo():
    if "arquivo" not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400

    arquivo = request.files["arquivo"]
    tipo = arquivo.filename.split(".")[-1].lower()

    arquivo.seek(0, 2)
    tamanho_arquivo = arquivo.tell()
    arquivo.seek(0)

    tipos_permitidos = ["xlsx", "csv"]

    if tipo not in tipos_permitidos:
        return (
            jsonify(
                {
                    "error": f"Tipo de arquivo não suportado .{tipo}. Permitidos .xlsx , .csv"
                }
            ),
            400,
        )

    status_arquivo = "OK"
    try:
        if tipo == "xlsx":
            df = pd.read_excel(arquivo)
        elif tipo == "csv":
            df = pd.read_csv(arquivo)
        else:
            return jsonify({"error": "Tipo de arquivo não suportado"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    colunas_corretas = ["CHV_CFE", "CNPJ", "RAZAO_SOCIAL", "NOME_REDE"]
    if not all(coluna in df.columns for coluna in colunas_corretas):
        cabecalhos_incorretos = [c for c in df.columns if c not in colunas_corretas]
        return (
            jsonify(
                {"error": f"Cabeçalhos incorretos: {', '.join(cabecalhos_incorretos)}"}
            ),
            400,
        )

    df["CNPJ_BASE"] = df["CNPJ"].str.replace(r"\D", "", regex=True).str[:8]
    cnpjs_sem_certificado = []

    try:
        for _, row in df.iterrows():
            cnpj_base = row["CNPJ_BASE"]
            certificado_existente = (
                db.session.query(Certificado)
                .filter(Certificado.CNPJ.startswith(cnpj_base))
                .first()
            )
            if not certificado_existente:
                cnpjs_sem_certificado.append(row["CNPJ"])
                status_arquivo = "ERROR"
                continue

            novo_registro = TbCfeFaltantes(
                ID=str(uuid.uuid4()),
                CHV_CFE=row["CHV_CFE"],
                CNPJ=row["CNPJ"],
                STATUS="CRIADO",
                RAZAO_SOCIAL=row["RAZAO_SOCIAL"],
                NOME_REDE=row["NOME_REDE"],
                DATA_FALTANTES=datetime.now(),
                USUARIO="user_name",
                NOME_MAQUINA="host_name",
            )
            db.session.add(novo_registro)

        registro_arquivo = ARQUIVOS_ROBOT(
            NOME_ARQUIVO=arquivo.filename,
            STATUS=status_arquivo,
            DATA_INSERCAO=datetime.now(),
        )
        db.session.add(registro_arquivo)

        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"Erro ao inserir os dados: {str(e)}"}), 500

    cnpj_mais_frequente = df["CNPJ"].value_counts().idxmax()
    cnpj = str(cnpj_mais_frequente)

    if cnpjs_sem_certificado:
        return (
            jsonify(
                {
                    "message": "Inserção não concluída, CNPJs sem certificados correspondentes."
                }
            ),
            400,
        )
    else:
        return (
            jsonify(
                {
                    "message": "Inserção concluída com sucesso",
                    "nome_arquivo": arquivo.filename,
                    "tamanho_arquivo_bytes": tamanho_arquivo,
                    "cnpj": cnpj,
                }
            ),
            200,
        )
